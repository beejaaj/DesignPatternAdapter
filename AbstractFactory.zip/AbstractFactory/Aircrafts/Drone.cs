﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AbstractFactory.Aircrafts
{
    public class Drone : IAircraft
    {
        public void CheckWind()
        {
            Console.WriteLine("computações emaquinações");
        }
        public void GetCargo()
        {
            Console.WriteLine("Produto capturado!");
        }
        public void StartRoute()
        {
            GetCargo(); CheckWind();
            Console.WriteLine("buscando correio");
        }
    }
}
