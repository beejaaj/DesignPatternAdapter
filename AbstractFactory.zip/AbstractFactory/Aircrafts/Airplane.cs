﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AbstractFactory.Aircrafts
{
    public class Airplane : IAircraft
    {
        public void CheckWind()
        {
            Console.WriteLine("Ventos a 25km!");
        }
        public void GetCargo()
        {
            Console.WriteLine("Vôo autorizado.");
        }
        public void StartRoute()
        {
            GetCargo();
            CheckWind();
            Console.WriteLine("Iniciando...");
        }
    }
}
