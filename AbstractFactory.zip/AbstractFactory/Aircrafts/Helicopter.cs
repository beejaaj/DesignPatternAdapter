﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AbstractFactory.Aircrafts
{
    public class Helicopter : IAircraft
    {
        public void CheckWind()
        {
            Console.WriteLine("não sei como checar");
        }
        public void GetCargo()
        {
            Console.WriteLine("Pegamo os presidente");
        }
        public void StartRoute()
        {
            GetCargo(); CheckWind();
            Console.WriteLine("Meliantes decolando");
        }
    }
}
