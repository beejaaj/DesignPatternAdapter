﻿// See https://aka.ms/new-console-template for more information
//using AbstractFactory;

//AbstractFactory.AbstractFactory factory = new WindowsFactory();
//IBotao botao = factory.CriarBotao();
//botao.Render();

using AbstractFactory.App;
using AbstractFactory.Factories;

static Application ConfigureApplication()
{
    Application app;
    ITransportFactory transportFactory;
    string company = "Lime"; string rota = "terrestre";
    if (company == "Uber")
    {
        transportFactory = new UberTransport();
    }
    else if (company == "99")
    {
        transportFactory = new _99Transport();
    }
    else transportFactory = new LimeTransport();
    app = new Application(transportFactory, rota);
    return app;
}

Application app = ConfigureApplication();
app.StartRoute();
Console.ReadLine();