﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AbstractFactory
{
    public interface IBotao
    {
        void Render();
    }
    public class BotaoWindows : IBotao
    {
        public void Render() => Console.WriteLine("Renderizando ...");
    }
    public class BotaoMac : IBotao
    {
        public void Render() => Console.WriteLine("Renderizando ...");
    }

    //--
    public interface AbstractFactory
    {
        IBotao CriarBotao();
    }
    public class WindowsFactory : AbstractFactory
    {
        public IBotao CriarBotao() => new BotaoWindows();
    }
    public class MacFactory : AbstractFactory
    {
        public IBotao CriarBotao() => new BotaoMac();
    }
}
