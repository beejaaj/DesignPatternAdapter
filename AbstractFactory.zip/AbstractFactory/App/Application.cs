﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using AbstractFactory.Aircrafts;
using AbstractFactory.Factories;
using AbstractFactory.Vehicles;

namespace AbstractFactory.App
{
    public class Application
    {
        private IAircraft aircraft;
        private IVehicle vehicle;
        private string rota;

        public Application(ITransportFactory factory, string rota)
        {
            this.rota = rota;
            if (rota == "terrestre") vehicle = factory.CreateTransportVehicle();
            else aircraft = factory.CreateTransportAircraft();
        }

        public void StartRoute()
        {
            if (rota == "terrestre") { vehicle.StartRoute(); }
            else { aircraft.StartRoute(); }
        }
    }
}
