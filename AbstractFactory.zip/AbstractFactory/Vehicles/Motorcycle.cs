﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AbstractFactory.Vehicles
{
    public class Motorcycle : IVehicle
    {
        public void GetCargo()
        {
            Console.WriteLine("Moto fazendo puta barulho");
        }
        public void StartRoute()
        {
            GetCargo();
            Console.WriteLine("Desastre por perto");
        }
    }
}
