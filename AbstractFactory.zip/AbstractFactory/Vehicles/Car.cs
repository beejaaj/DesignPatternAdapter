﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AbstractFactory.Vehicles
{

    public class Car : IVehicle
    {
        public void GetCargo()
        {
            Console.WriteLine("Carrinho decolando");
        }
        public void StartRoute()
        {
            GetCargo();
            Console.WriteLine("Iniciando corrida");
        }
    }
}
