﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AbstractFactory.Vehicles
{
    public interface IVehicle
    {
        void StartRoute();
        void GetCargo();
    }
}
