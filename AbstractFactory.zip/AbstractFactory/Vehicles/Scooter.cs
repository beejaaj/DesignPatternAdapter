﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AbstractFactory.Vehicles
{
    public class Scooter : IVehicle
    {
        public void GetCargo()
        {
            Console.WriteLine("energizando");
        }
        public void StartRoute()
        {
            GetCargo();
            Console.WriteLine("Iniciando rolê");
        }
    }
}
