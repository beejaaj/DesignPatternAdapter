﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using AbstractFactory.Aircrafts;
using AbstractFactory.Vehicles;

namespace AbstractFactory.Factories
{
    public class _99Transport : ITransportFactory
    {
        public IAircraft CreateTransportAircraft()
        {
            return new Helicopter();
        }
        public IVehicle CreateTransportVehicle()
        {
            return new Motorcycle();
        }
    }
}
