﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.ConstrainedExecution;
using System.Text;
using System.Threading.Tasks;
using AbstractFactory.Aircrafts;
using AbstractFactory.Vehicles;

namespace AbstractFactory.Factories
{
    public class UberTransport : ITransportFactory
    {
        public IAircraft CreateTransportAircraft()
        {
            return new Airplane();
        }
        public IVehicle CreateTransportVehicle()
        {
            return new Car();
        }
    }
}
