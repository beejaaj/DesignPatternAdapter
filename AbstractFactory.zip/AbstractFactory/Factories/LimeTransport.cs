﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using AbstractFactory.Aircrafts;
using AbstractFactory.Vehicles;

namespace AbstractFactory.Factories
{
    public class LimeTransport : ITransportFactory
    {
        public IAircraft CreateTransportAircraft()
        {
            return new Drone();
        }
        public IVehicle CreateTransportVehicle()
        {
            return new Scooter();
        }
    }
}
