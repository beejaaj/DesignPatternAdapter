﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using AbstractFactory.Aircrafts;
using AbstractFactory.Vehicles;

namespace AbstractFactory.Factories
{
    public interface ITransportFactory
    {
        IAircraft CreateTransportAircraft();
        IVehicle CreateTransportVehicle();
    }
}
