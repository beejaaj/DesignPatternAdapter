﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProxyPattern_07_04_25
{
    //internal class Exemplo_ProxyPatterns
    //{
    //}
    // Interface para a imagem
    public interface IImage
    {
        void Display();
    }
    // Classe da imagem real
    public class RealImage : IImage
    {
        private string _filename;
        public RealImage(string filename)
        {
            _filename = filename;
            LoadFromDisk(_filename);
        }
        private void LoadFromDisk(string filename)
        {
            Console.WriteLine($"Loading {_filename} from disk.");
        }
        public void Display()
        {
            Console.WriteLine($"Displaying {_filename}");
        }
    }
    // Proxy com controle de acesso
    public class AccessControlProxyImage : IImage
    {
        private RealImage? _realImage; // Campo anulável
        private string _filename;
        private bool _hasAccess;
        public AccessControlProxyImage(string filename, bool hasAccess)
        {
            _filename = filename;
            _hasAccess = hasAccess;
        }
        public void Display()
        {
            if (_hasAccess)
            {
                if (_realImage == null)
                {
                    _realImage = new RealImage(_filename);
                }
                _realImage.Display();
            }
            else
            {
                Console.WriteLine($"Access denied to {_filename}");
            }
        }
    }
    // Proxy com lazy initialization
    public class LazyProxyImage : IImage
    {
        private RealImage? _realImage; // Campo anulável
        private string _filename;
        public LazyProxyImage(string filename)
        {
            _filename = filename;
        }
        public void Display()
        {
            if (_realImage == null)
            {
                _realImage = new RealImage(_filename);
            }
            _realImage.Display();
        }
    }
    // Proxy com logging
    public class LoggingProxyImage : IImage
    {
        private RealImage? _realImage; // Campo anulável
        private string _filename;
        public LoggingProxyImage(string filename)
        {
            _filename = filename;
        }
        public void Display()
        {
            LogAccess();
            if (_realImage == null)
            {
                _realImage = new RealImage(_filename);
            }
            _realImage.Display();
        }
        private void LogAccess()
        {
            Console.WriteLine($"Accessing {_filename} on {DateTime.Now}");
        }
    }
}
