﻿using ProxyPattern_07_04_25;
/*
Console.WriteLine("Demonstração do Padrão de Projeto Proxy");
// Exemplo 1: Proxy com Controle de Acesso
Console.WriteLine("\nExemplo 1: Proxy com Controle de Acesso");
IImage accessControlImage = new AccessControlProxyImage("test_10mb.jpg", true);
accessControlImage.Display();
IImage deniedAccessImage = new AccessControlProxyImage("test_10mb.jpg", false);
deniedAccessImage.Display();
// Exemplo 2: Proxy com Lazy Initialization
Console.WriteLine("\nExemplo 2: Proxy com Lazy Initialization");
IImage lazyImage = new LazyProxyImage("test_20mb.jpg");
Console.WriteLine("Imagem ainda não carregada.");
lazyImage.Display();
lazyImage.Display();
// Exemplo 3: Proxy com Logging
Console.WriteLine("\nExemplo 3: Proxy com Logging");
IImage loggedImage = new LoggingProxyImage("test_30mb.jpg");
loggedImage.Display();
loggedImage.Display(); */

//--

IFileDownloader downloader = new FileDownloaderProxy();

while (true)
{
    Console.WriteLine("Digite a URL do arquivo (ou 'sair' para encerrar):");
    string input = Console.ReadLine();

    if (input?.ToLower() == "sair")
    {
        Console.WriteLine("Encerrando o programa.");
        break;
    }

    downloader.DownloadFile(input);
}