﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProxyPattern_07_04_25
{
    //internal class Exercicio_Proxy
    //{
    //}

    public interface IFileDownloader
    {
        void DownloadFile(string url);
    }
    public class FileDownloadService : IFileDownloader
    {
        public void DownloadFile(string url)
        {
            Console.WriteLine($"Baixando o arquivo de: {url}");
            Thread.Sleep(1000); // Simulando tempo de download
            Console.WriteLine("Download concluído!\n");
        }
    }

    public class FileDownloaderProxy : IFileDownloader
    {
        private FileDownloadService _realService = new FileDownloadService();
        private Dictionary<string, bool> _cache = new Dictionary<string, bool>();

        public void DownloadFile(string url)
        {
            if (_cache.ContainsKey(url))
            {
                Console.WriteLine("Arquivo já baixado anteriormente. Usando cache.\n");
                return;
            }

            Console.WriteLine($"Deseja baixar o arquivo de {url}? (s/n)");
            string resposta = Console.ReadLine()?.ToLower();

            if (resposta == "s")
            {
                _realService.DownloadFile(url);
                _cache[url] = true;
            }
            else
            {
                Console.WriteLine("Download cancelado pelo usuário.\n");
            }
        }
    }
}