﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Text;
using System.Threading.Tasks;

namespace FactoryDesignPattern
{
    public interface IVehicle
    {
        void StartRoute();
        //void GetCargo();
    }
    public abstract class VehicleFactory
    {
        public void StartTransport()
        {
            IVehicle vehicle = CriarTransporte();
            vehicle.StartRoute();
        }
        protected abstract IVehicle CriarTransporte();
    }
    public class CarroCreator:VehicleFactory
    {
        protected override IVehicle CriarTransporte()
        {
            return new Carro();
            //Carro.StartRoute();
        }
    }
    public class MotoCreator:VehicleFactory
    {
        protected override IVehicle CriarTransporte()
        {
            return new Moto();
            //Moto.StartRoute();
        }
    }
    public class BicicletaCreator:VehicleFactory
    {
        protected override IVehicle CriarTransporte()
        {
            return new Bicicleta();
            //Bicicleta.StartRoute();
        }
    }
    public class Carro:IVehicle
    {
        public void StartRoute() { Console.WriteLine("CARRO."); }
        public void GetCargo(int pessoas) { Console.WriteLine($"Transportando '{pessoas}' pessoas"); }
    }
    public class Bicicleta:IVehicle
    {
        public void StartRoute() { Console.WriteLine("BICICLETA."); }
        public void GetCargo(string owner) { Console.WriteLine($"Sendo dirigida por '{owner}'"); }
    }
    public class Moto:IVehicle
    {
        public void StartRoute() { Console.WriteLine("MOTO."); }
        public void GetCargo(string produto) { Console.WriteLine($"Entregando '{produto}' por moto"); }
    }
    public class Cliente
    {
        protected readonly VehicleFactory _factory;
        protected readonly IVehicle _vehicle;

        public Cliente(VehicleFactory factory)
        {
            _factory = factory;
            _vehicle = _factory.CriarTransporte();
        }

        public void StartRoute(string carga)
        {
            _vehicle.StartRoute(carga);
        }
    }
}