﻿using AdapterExemplo;

var cliente = new ClienteNotificacao();
var smsLegado = new SmsLegado();
var adapter = new SmsParaNotificacaoAdapter(smsLegado);
cliente.DispararNotificacao(adapter);