﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PaymentAdapter
{
    public interface Pagamentos
    {
        void Payment();
        void Receive();
    }
    public class Payoneer //: Pagamentos
    {
        public void aPayment() { Console.WriteLine("?"); }
        public void aReceive() { Console.WriteLine("!"); }
    }
    public class PayoneerAdapter : Pagamentos
    {
        private Payoneer payoneer;
        public PayoneerAdapter(Payoneer payoneer) { this.payoneer = payoneer; }
        public void Payment() { Console.WriteLine("??"); }
        public void Receive() { Console.WriteLine("!!"); }
    }
    public class MercadoPago //: Pagamentos
    {
        public void bPayment() { Console.WriteLine("!?"); }
        public void bReceive() { Console.WriteLine("?!"); }
    }
    public class MercadoPagoAdapter : Pagamentos
    {
        private MercadoPago market;
        public MercadoPagoAdapter(MercadoPago market) { this.market = market; }
        public void Payment() { Console.WriteLine("!??"); }
        public void Receive() { Console.WriteLine("?!!"); }
    }
    //public class Cliente : Pagamentos
    //{
    //    public void Payment() { Console.WriteLine("??!"); }
    //    public void Receive() { Console.WriteLine("!!?"); }
    //}
}