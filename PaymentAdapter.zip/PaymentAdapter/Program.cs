﻿using PaymentAdapter;
MercadoPago mercadinho = new MercadoPago();
Payoneer maquininha = new Payoneer();

MercadoPagoAdapter mercadinho_adaptado = new MercadoPagoAdapter(mercadinho);
PayoneerAdapter maquininha_adaptado = new PayoneerAdapter(maquininha);

mercadinho_adaptado.Payment();
maquininha_adaptado.Receive();